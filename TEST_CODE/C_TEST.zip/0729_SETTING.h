//#ifndef 0729_SETTING_H_INCLUDED
//#define 0729_SETTING_H_INCLUDED

#ifndef _0729_SETTING_H_
#define _0729_SETTING_H_


void test_1();
void test_2();
void swap_ptr(char **ppa, char **ppb);
void MALLOC_FREE();
void MALLOC_TEST2();


#endif // 0729_SETTING_H_INCLUDED
