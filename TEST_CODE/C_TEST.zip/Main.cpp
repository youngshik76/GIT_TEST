#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "0729_SETTING.h"
#include "struct.h"

extern char name3[];

struct student s1;

int main(void)
{
    //test_1();
    //test_2();
    //MALLOC_FREE();
    //MALLOC_TEST2();


    //printf("name_main:%s\n",you.name);
    write_profile(name3,727,48,175,"�׻� �ǰ��ϼ���");


    return 0;
}
